<?php

namespace App\Extension;

use App\Entity\Ticket;
use App\Entity\Types\TicketStatus;
use Doctrine\Common\Collections\Criteria;
use Doctrine\ORM\QueryBuilder;

class TicketCollectionExtension extends BaseExtension
{
    /**
     * @param QueryBuilder $queryBuilder
     * @param string $resourceClass
     * @param string $rootAlias
     * @param array $context
     * @throws \Exception
     */
    protected function addWhereWithRootAlias(QueryBuilder $queryBuilder, string $resourceClass, string $rootAlias, array $context = [])
    {
        $latitude  = 48.535057;
        $longitude = 8.085793;

        if (Ticket::class === $resourceClass) {
            $queryBuilder
                ->andWhere(sprintf('%s.status >= :open', $rootAlias))
                ->addSelect(sprintf(
                    '( 3959 * ACOS(COS(RADIANS(' . $latitude . '))' .
                    '* COS( RADIANS( %1$s.address.latitude ) )' .
                    '* COS( RADIANS( %1$s.address.longitude )' .
                    '- RADIANS(' . $longitude . ') )' .
                    '+ SIN( RADIANS(' . $latitude . ') )' .
                    '* SIN( RADIANS( %1$s.address.latitude ) ) ) ) AS distance',
                    $rootAlias
                ))
                ->orderBy('distance', Criteria::ASC)
                ->setParameter('open', TicketStatus::OPEN)
            ;
        }
    }
}