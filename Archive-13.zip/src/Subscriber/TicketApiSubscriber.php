<?php

namespace App\Subscriber;

use ApiPlatform\Core\EventListener\EventPriorities;
use App\Entity\Ticket;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpKernel\Event\ViewEvent;
use Symfony\Component\HttpKernel\KernelEvents;

class TicketApiSubscriber implements EventSubscriberInterface
{
    /**
     * @param ViewEvent $event
     */
    public function checkAddress(ViewEvent $event)
    {
        $request = $event->getRequest();
        $method  = $request->getMethod();
        $entity  = $event->getControllerResult();

        if ($method === Request::METHOD_POST && $entity instanceof Ticket) {
            $ticketAddress = $entity->getAddress();

            if ($ticketAddress) {
                $user = new User(); // TODO

                $userAddress = $user->getAddress();

                $entity->setAddress($userAddress);
            }
        }
    }

    /**
     * @inheritDoc
     */
    public static function getSubscribedEvents()
    {
        return [
            KernelEvents::VIEW => ['checkAddress', EventPriorities::PRE_WRITE],
        ];
    }
}